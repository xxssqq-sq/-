main() { __asm__("xorb %al, %al"); }
